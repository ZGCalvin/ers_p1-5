$(document).ready(function(){


	$("#loginform").click(function(){
		$("#body").load("resources/loginform.html");
	});
	$("#registerform").click(function(){
    	$("#body").load("resources/registerform.html");
    });

  
  });
